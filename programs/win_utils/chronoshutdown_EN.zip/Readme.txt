Chrono Shutdown Ver 1.12 (Freeware) by John O'Byrne

Works under NT4/Win2k/winXP

Description:
------------

Chrono Shutdown is a software which permits automatically to shutdown/reboot the computer after a
certain amount of time chosen by the user. It may be useful to shutdown the computer after a quite
long download

Install: Just launch it
--------

Uninstall: Simply remove the executable and the .ini file associated with it (no writes in the registry)
----------

Limitations / Bugs:
-------------------
Doesn't shutdown on computers which don't permit a poweroff (ATX Power supply needed)
Doesn't shutdown under Win 95/98/ME

History / changes:
----------------
04/11/2001: Version 1.12
            -Corrected a few bugs

17/10/2001: Version 1.11
            -Added WinXP look
            -Now the application is able to warn the USER a defined time before shutting down
            -All the params are written in a .ini file
            -Cleaned a little bit the user Interface
            -The User is now able to choose the warning sound

01/10/2001: version 1.0
            -Original release

Comments/Bugs : john.obyrne@free.fr
Updates : http://john.obyrne.free.fr/index.php3?page=chronoshutdown